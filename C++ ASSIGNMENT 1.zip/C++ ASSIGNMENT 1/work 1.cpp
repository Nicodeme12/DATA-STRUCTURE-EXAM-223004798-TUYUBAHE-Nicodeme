#include <iostream>  // Include input-output library
using namespace std; // Use standard namespace

int main() {  // Main function
    cout << "Hello, World!";  // Print output to the screen
    return 0;  // Return 0 to indicate successful execution
}

